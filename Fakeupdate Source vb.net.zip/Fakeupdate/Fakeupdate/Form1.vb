﻿Public Class Form1
    Dim Persistent = False
    Private Sub Form1_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = Persistent
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        On Error Resume Next
        Me.WindowState = FormWindowState.Maximized
        CheckForIllegalCrossThreadCalls = False
        Me.TopMost = True
        Dim clArgs() As String = Environment.GetCommandLineArgs()

        If clArgs.Count >= 2 Then

            If clArgs(1).ToString = "w10_update" Then
                WebBrowser1.Navigate("https://fakeupdate.net/win10/")
                WebBrowser1.Size = WebBrowser1.Document.Body.ScrollRectangle.Size
            End If

            If clArgs(1).ToString = "virus" Then
                WebBrowser1.Navigate("https://fakeupdate.net/wnc/")
                WebBrowser1.Size = WebBrowser1.Document.Body.ScrollRectangle.Size
            End If
            If clArgs(1).ToString = "virus_persistent" Then
                WebBrowser1.Navigate("https://fakeupdate.net/wnc/")
                WebBrowser1.Size = WebBrowser1.Document.Body.ScrollRectangle.Size
                Persistent = True
            End If
            If clArgs(1).ToString = "broken" Then
                WebBrowser1.Visible = False
                PictureBox1.Visible = True
            End If
        Else
            WebBrowser1.Navigate("https://fakeupdate.net/win10/")
            WebBrowser1.Size = WebBrowser1.Document.Body.ScrollRectangle.Size
        End If



    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub
End Class
